package com.example.myapplicationdc.Activity

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplicationdc.Adapter.FavoriteDoctorAdapter
import com.example.myapplicationdc.Domain.DoctorModel
import com.example.myapplicationdc.R
import com.example.myapplicationdc.databinding.ActivityDetailBinding
import com.example.myapplicationdc.databinding.ActivityFavouritesBinding

class FavouritesActivity : AppCompatActivity() {

    private lateinit var favoriteDoctorAdapter: FavoriteDoctorAdapter
    private lateinit var binding: ActivityFavouritesBinding
    private lateinit var recyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityFavouritesBinding.inflate(layoutInflater)
        setContentView(binding.root) // Use binding.root instead of R.layout.activity_favourites

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        binding.backBtn.setOnClickListener {
            finish()
        }

        // Initialize the RecyclerView
        recyclerView = binding.viewFavouriteList // Use binding to access the RecyclerView
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Initialize the adapter with an empty list and unfavorite callback
        favoriteDoctorAdapter = FavoriteDoctorAdapter(emptyList()) { doctor, position ->
            // Handle unfavorite action here, e.g., remove from favorites
            removeFromFavorites(doctor, position)
        }

        recyclerView.adapter = favoriteDoctorAdapter

        // Check if the adapter has items and update visibility
        updateFavoriteVisibility()

        // Load favorite doctors data (this could be from a database or a network request)
        loadFavoriteDoctors()
    }

    private fun updateFavoriteVisibility() {
        if (favoriteDoctorAdapter.itemCount == 0) {
            binding.noFavoutiteTextView.visibility = View.VISIBLE
            binding.viewFavouriteList.visibility = View.GONE
        } else {
            binding.noFavoutiteTextView.visibility = View.GONE
            binding.viewFavouriteList.visibility = View.VISIBLE
        }
    }

    private fun loadFavoriteDoctors() {

    }

    private fun removeFromFavorites(doctor: DoctorModel, position: Int) {
        // Implement the logic to remove the doctor from the favorites
        // Update the data source and notify the adapter
        val updatedList = favoriteDoctorAdapter.items.toMutableList()
        updatedList.removeAt(position)
        favoriteDoctorAdapter.updateData(updatedList)
        updateFavoriteVisibility() // Update visibility after removing
    }
}