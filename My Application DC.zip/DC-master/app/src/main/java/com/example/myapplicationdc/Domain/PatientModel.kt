import android.os.Parcel
import android.os.Parcelable
import com.example.myapplicationdc.Domain.DoctorModel

data class PatientModel(
    var id: Int = 0,
    var pname: String = "",
    var age: Int = 0,
    var gender: String = "",
    var medicalHistory: String = "",
    var prescriptionPictures: String = "",
    var favoriteDoctors: MutableList<DoctorModel> = mutableListOf() // Add favorite doctors list
) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readInt(),
        parcel.readString().toString(),
        parcel.readInt(),
        parcel.readString().toString(),
        parcel.readString().toString(),
        parcel.readString().toString(),
        parcel.createTypedArrayList(DoctorModel.CREATOR)!! // Add this line for favoriteDoctors
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeInt(id)
        parcel.writeString(pname)
        parcel.writeInt(age)
        parcel.writeString(gender)
        parcel.writeString(medicalHistory)
        parcel.writeString(prescriptionPictures)
        parcel.writeTypedList(favoriteDoctors) // Write favoriteDoctors to the parcel
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<PatientModel> {
        override fun createFromParcel(parcel: Parcel): PatientModel {
            return PatientModel(parcel)
        }

        override fun newArray(size: Int): Array<PatientModel?> {
            return arrayOfNulls(size)
        }
    }
}
