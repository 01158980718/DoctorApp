package com.example.myapplicationdc.Adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.myapplicationdc.Activity.Profile.AppointmentActivity
import com.example.myapplicationdc.Domain.DoctorModel
import com.example.myapplicationdc.databinding.ViewholderFavoriteBinding

class FavoriteDoctorAdapter(
    var items: List<DoctorModel>,
    private val onUnfavorite: (DoctorModel, Int) -> Unit
) : RecyclerView.Adapter<FavoriteDoctorAdapter.ViewHolder>() {

    private var context: Context? = null

    class ViewHolder(val binding: ViewholderFavoriteBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        context = parent.context
        val binding = ViewholderFavoriteBinding.inflate(LayoutInflater.from(context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val doctor = items[position]
        holder.binding.doctorNameTextView.text = doctor.Name
        holder.binding.doctorSpecial.text = doctor.Special

        // Load doctor's image
        Glide.with(holder.itemView.context)
            .load(doctor.Picture)
            .into(holder.binding.doctorImageView)

        // Unfavorite button listener
        holder.binding.unfavIcon.setOnClickListener {
            onUnfavorite(doctor, position)
        }

        // Open AppointmentActivity when clicking on the item
        holder.binding.root.setOnClickListener {
            val intent = Intent(holder.itemView.context, AppointmentActivity::class.java)
            intent.putExtra("DOCTOR_ID", doctor.Id)
            holder.itemView.context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int = items.size

    // Update adapter data
    fun updateData(newItems: List<DoctorModel>) {
        this.items = newItems
        notifyDataSetChanged()
    }
}
